﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[CreateAssetMenu(fileName = "pos", menuName = "POS")]

public class SO : ScriptableObject
{
    public int[] pos;
}
