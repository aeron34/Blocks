﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using TMPro;
public class Online : MonoBehaviour
{
    static readonly HttpClient h = new HttpClient();

    // Start is called before the first frame update
    void Start()
    {
    }

    public void Get()
    {
        Login();
    }

    private static async Task Login()
    {
        var u = GameObject.Find("username").GetComponent<TMP_InputField>().text;
        var p = GameObject.Find("password").GetComponent<TMP_InputField>().text;

        string a = $"http://localhost:3000/login?username={u}&pass={p}";

        var content = await h.GetStringAsync(a);

        Debug.Log(content);
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
